const express = require('express');
const pa11y = require('pa11y');
const path = require('path');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.get('/', (req, res) => {
    res.render('index');
});

app.post('/test', async (req, res) => {
    const url = req.body.url;
    try {
        const results = await pa11y(url, {
            standard: 'WCAG2AAA',
            includeNotices: true,
            includeWarnings: true,
        });
        res.render('results', { url, results });
    } catch (error) {
        res.render('results', { url, results: { issues: [{ message: error.message }] } });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Accessibility tool running on http://localhost:${PORT}`);
});
