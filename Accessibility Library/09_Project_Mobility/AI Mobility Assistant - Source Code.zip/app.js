// AI-Powered Mobility Assistant App
class MobilityAssistantApp {
  constructor() {
    this.currentScreen = 'welcome-screen';
    this.selectedMode = null;
    this.isNavigating = false;
    this.obstacleDetectionActive = false;
    
    // User settings with defaults
    this.settings = {
      modes: {
        wheelchairNav: false,
        obstacleDetection: false
      },
      voice: {
        type: 'female',
        speed: 1.0,
        verbosity: 'medium'
      },
      accessibility: {
        highContrast: false,
        fontSize: 1.0,
        hapticFeedback: true
      }
    };
    
    this.init();
  }
  
  init() {
    this.bindEvents();
    this.updateModeDisplay();
    this.applySettings();
    this.announceToScreenReader('AI-Powered Mobility Assistant loaded. Ready to assist with navigation.');
  }
  
  bindEvents() {
    // Welcome screen
    document.getElementById('get-started-btn').addEventListener('click', () => {
      this.showScreen('mode-selection-screen');
      this.announceToScreenReader('Mode selection screen loaded. Choose your assistance mode.');
    });
    
    // Mode selection
    document.querySelectorAll('.mode-card').forEach(card => {
      card.addEventListener('click', (e) => this.handleModeSelection(e));
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          this.handleModeSelection(e);
        }
      });
    });
    
    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => this.handleNavigation(e));
    });
    
    // Obstacle detection
    document.getElementById('obstacle-detection-btn').addEventListener('click', () => {
      this.startObstacleDetection();
    });
    
    document.getElementById('stop-detection-btn').addEventListener('click', () => {
      this.stopObstacleDetection();
    });
    
    document.getElementById('end-trip-btn').addEventListener('click', () => {
      this.endTrip();
    });
    
    // Search functionality
    document.getElementById('destination-input').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        this.handleSearch();
      }
    });
    
    document.querySelector('.search-btn').addEventListener('click', () => {
      this.handleSearch();
    });
    
    // Settings
    this.bindSettingsEvents();
  }
  
  bindSettingsEvents() {
    // Mode toggles
    document.getElementById('wheelchair-nav-toggle').addEventListener('change', (e) => {
      this.settings.modes.wheelchairNav = e.target.checked;
      this.updateModeDisplay();
      this.saveSettings();
      this.simulateHapticFeedback();
    });
    
    document.getElementById('obstacle-detect-toggle').addEventListener('change', (e) => {
      this.settings.modes.obstacleDetection = e.target.checked;
      this.updateModeDisplay();
      this.saveSettings();
      this.simulateHapticFeedback();
    });
    
    // Voice settings
    document.getElementById('voice-type').addEventListener('change', (e) => {
      this.settings.voice.type = e.target.value;
      this.saveSettings();
      this.announceToScreenReader(`Voice type changed to ${e.target.value}`);
    });
    
    document.getElementById('voice-speed').addEventListener('input', (e) => {
      this.settings.voice.speed = parseFloat(e.target.value);
      document.getElementById('voice-speed-value').textContent = `${e.target.value}x`;
      this.saveSettings();
    });
    
    document.getElementById('voice-verbosity').addEventListener('change', (e) => {
      this.settings.voice.verbosity = e.target.value;
      this.saveSettings();
      this.announceToScreenReader(`Verbosity level changed to ${e.target.value}`);
    });
    
    // Accessibility settings
    document.getElementById('high-contrast-toggle').addEventListener('change', (e) => {
      this.settings.accessibility.highContrast = e.target.checked;
      this.applyHighContrast();
      this.saveSettings();
      this.simulateHapticFeedback();
    });
    
    document.getElementById('font-size').addEventListener('input', (e) => {
      this.settings.accessibility.fontSize = parseFloat(e.target.value);
      document.getElementById('font-size-value').textContent = `${e.target.value}x`;
      this.applyFontSize();
      this.saveSettings();
    });
    
    document.getElementById('haptic-feedback-toggle').addEventListener('change', (e) => {
      this.settings.accessibility.hapticFeedback = e.target.checked;
      this.saveSettings();
      if (e.target.checked) {
        this.simulateHapticFeedback();
      }
    });
  }
  
  handleModeSelection(event) {
    const mode = event.currentTarget.dataset.mode;
    
    // Remove previous selections
    document.querySelectorAll('.mode-card').forEach(card => {
      card.classList.remove('selected');
      card.setAttribute('aria-checked', 'false');
    });
    
    // Select current mode
    event.currentTarget.classList.add('selected');
    event.currentTarget.setAttribute('aria-checked', 'true');
    this.selectedMode = mode;
    
    // Update settings based on mode
    switch (mode) {
      case 'wheelchair':
        this.settings.modes.wheelchairNav = true;
        this.settings.modes.obstacleDetection = false;
        break;
      case 'visual':
        this.settings.modes.wheelchairNav = false;
        this.settings.modes.obstacleDetection = true;
        break;
      case 'combined':
        this.settings.modes.wheelchairNav = true;
        this.settings.modes.obstacleDetection = true;
        break;
    }
    
    this.simulateHapticFeedback();
    this.announceToScreenReader(`${event.currentTarget.querySelector('h3').textContent} mode selected`);
    
    // Auto-advance to navigation screen after selection
    setTimeout(() => {
      this.showScreen('navigation-screen');
      this.updateModeDisplay();
      this.updateSettingsFromMode();
    }, 500);
  }
  
  handleNavigation(event) {
    const targetScreen = event.currentTarget.dataset.screen;
    
    // Update active nav item
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.remove('active');
      item.setAttribute('aria-current', 'false');
    });
    
    event.currentTarget.classList.add('active');
    event.currentTarget.setAttribute('aria-current', 'page');
    
    // Show target screen
    if (targetScreen === 'navigation') {
      this.showScreen(this.isNavigating ? 'navigating-screen' : 'navigation-screen');
    } else {
      this.showScreen(`${targetScreen}-screen`);
    }
    
    this.simulateHapticFeedback();
  }
  
  handleSearch() {
    const destination = document.getElementById('destination-input').value.trim();
    
    if (!destination) {
      this.announceToScreenReader('Please enter a destination');
      return;
    }
    
    // Simulate navigation start
    this.showLoadingOverlay();
    this.announceToScreenReader(`Searching for route to ${destination}`);
    
    setTimeout(() => {
      this.hideLoadingOverlay();
      this.startNavigation(destination);
    }, 2000);
  }
  
  startNavigation(destination) {
    this.isNavigating = true;
    this.showScreen('navigating-screen');
    this.announceToScreenReader(`Navigation started to ${destination}. Follow the turn-by-turn instructions.`);
    
    // Update navigation instructions periodically
    this.startNavigationUpdates();
  }
  
  startNavigationUpdates() {
    const instructions = [
      { direction: '↗️', text: 'Turn right in 50 meters', street: 'Continue on Main Street' },
      { direction: '⬆️', text: 'Continue straight for 200 meters', street: 'Stay on Main Street' },
      { direction: '↖️', text: 'Turn left in 100 meters', street: 'onto Oak Avenue' },
      { direction: '🎯', text: 'Destination reached', street: 'You have arrived' }
    ];
    
    let currentInstruction = 0;
    
    const updateInterval = setInterval(() => {
      if (!this.isNavigating || currentInstruction >= instructions.length) {
        clearInterval(updateInterval);
        if (currentInstruction >= instructions.length) {
          this.endTrip();
        }
        return;
      }
      
      const instruction = instructions[currentInstruction];
      this.updateNavigationInstruction(instruction);
      currentInstruction++;
    }, 5000);
  }
  
  updateNavigationInstruction(instruction) {
    document.querySelector('.turn-icon').textContent = instruction.direction;
    document.querySelector('.instruction-text h3').textContent = instruction.text;
    document.querySelector('.instruction-text p').textContent = instruction.street;
    
    // Announce to screen reader
    this.announceToScreenReader(`${instruction.text}. ${instruction.street}`);
  }
  
  startObstacleDetection() {
    this.obstacleDetectionActive = true;
    this.showOverlay('obstacle-detection-overlay');
    this.announceToScreenReader('Obstacle detection started. Camera is now scanning for obstacles.');
    
    // Simulate obstacle detection alerts
    this.simulateObstacleDetection();
  }
  
  simulateObstacleDetection() {
    const alerts = [
      'Path clear ahead',
      'Slight obstacle detected on the right',
      'Curb approaching in 3 meters',
      'Path clear, continue forward'
    ];
    
    let alertIndex = 0;
    const alertInterval = setInterval(() => {
      if (!this.obstacleDetectionActive) {
        clearInterval(alertInterval);
        return;
      }
      
      const alert = alerts[alertIndex % alerts.length];
      this.announceToScreenReader(alert);
      alertIndex++;
    }, 3000);
  }
  
  stopObstacleDetection() {
    this.obstacleDetectionActive = false;
    this.hideOverlay('obstacle-detection-overlay');
    this.announceToScreenReader('Obstacle detection stopped.');
  }
  
  endTrip() {
    this.isNavigating = false;
    this.obstacleDetectionActive = false;
    this.showScreen('navigation-screen');
    this.announceToScreenReader('Trip ended. You can start a new journey.');
    
    // Clear destination input
    document.getElementById('destination-input').value = '';
  }
  
  showScreen(screenId) {
    // Hide all screens
    document.querySelectorAll('.screen').forEach(screen => {
      screen.classList.add('hidden');
    });
    
    // Show target screen
    document.getElementById(screenId).classList.remove('hidden');
    this.currentScreen = screenId;
    
    // Focus management
    this.manageFocus(screenId);
  }
  
  manageFocus(screenId) {
    // Focus on the main heading or first interactive element
    const screen = document.getElementById(screenId);
    const focusTarget = screen.querySelector('h1, h2, button, input, .mode-card');
    
    if (focusTarget) {
      setTimeout(() => {
        focusTarget.focus();
      }, 100);
    }
  }
  
  showOverlay(overlayId) {
    document.getElementById(overlayId).classList.remove('hidden');
  }
  
  hideOverlay(overlayId) {
    document.getElementById(overlayId).classList.add('hidden');
  }
  
  showLoadingOverlay() {
    this.showOverlay('loading-overlay');
  }
  
  hideLoadingOverlay() {
    this.hideOverlay('loading-overlay');
  }
  
  updateModeDisplay() {
    const modeDisplay = document.getElementById('current-mode-display');
    const modes = [];
    
    if (this.settings.modes.wheelchairNav) {
      modes.push('Wheelchair Navigation');
    }
    if (this.settings.modes.obstacleDetection) {
      modes.push('Obstacle Detection');
    }
    
    if (modes.length === 0) {
      modeDisplay.textContent = 'No assistance mode selected';
      modeDisplay.className = 'status status--warning';
    } else {
      modeDisplay.textContent = modes.join(' + ');
      modeDisplay.className = 'status status--success';
    }
  }
  
  updateSettingsFromMode() {
    // Update settings screen checkboxes based on selected modes
    document.getElementById('wheelchair-nav-toggle').checked = this.settings.modes.wheelchairNav;
    document.getElementById('obstacle-detect-toggle').checked = this.settings.modes.obstacleDetection;
  }
  
  applySettings() {
    this.applyHighContrast();
    this.applyFontSize();
    this.updateVoiceSpeedDisplay();
    this.updateFontSizeDisplay();
  }
  
  applyHighContrast() {
    if (this.settings.accessibility.highContrast) {
      document.body.classList.add('high-contrast');
    } else {
      document.body.classList.remove('high-contrast');
    }
  }
  
  applyFontSize() {
    document.body.style.fontSize = `${this.settings.accessibility.fontSize}rem`;
  }
  
  updateVoiceSpeedDisplay() {
    document.getElementById('voice-speed-value').textContent = `${this.settings.voice.speed}x`;
  }
  
  updateFontSizeDisplay() {
    document.getElementById('font-size-value').textContent = `${this.settings.accessibility.fontSize}x`;
  }
  
  saveSettings() {
    // In a real app, this would save to a backend or local storage
    // For demo purposes, we'll just show a success message
    this.showSuccessToast('Settings saved successfully');
  }
  
  showSuccessToast(message) {
    const toast = document.getElementById('success-toast');
    const messageElement = toast.querySelector('.toast-message');
    
    messageElement.textContent = message;
    toast.classList.remove('hidden');
    
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 3000);
  }
  
  simulateHapticFeedback() {
    if (!this.settings.accessibility.hapticFeedback) return;
    
    // Simulate haptic feedback with a visual pulse
    document.body.style.transition = 'transform 0.1s ease';
    document.body.style.transform = 'scale(1.001)';
    
    setTimeout(() => {
      document.body.style.transform = 'scale(1)';
      setTimeout(() => {
        document.body.style.transition = '';
      }, 100);
    }, 50);
    
    // Use vibration API if available
    if ('vibrate' in navigator) {
      navigator.vibrate(50);
    }
  }
  
  announceToScreenReader(message) {
    // Create a live region for screen reader announcements
    let liveRegion = document.getElementById('live-region');
    
    if (!liveRegion) {
      liveRegion = document.createElement('div');
      liveRegion.id = 'live-region';
      liveRegion.setAttribute('aria-live', 'polite');
      liveRegion.setAttribute('aria-atomic', 'true');
      liveRegion.className = 'sr-only';
      document.body.appendChild(liveRegion);
    }
    
    // Clear and set new message
    liveRegion.textContent = '';
    setTimeout(() => {
      liveRegion.textContent = message;
    }, 100);
  }
  
  // Keyboard navigation support
  handleKeyboardNavigation(event) {
    const focusableElements = document.querySelectorAll(
      'button, input, select, textarea, [tabindex]:not([tabindex="-1"]), .mode-card'
    );
    
    const currentIndex = Array.from(focusableElements).indexOf(document.activeElement);
    
    switch (event.key) {
      case 'ArrowDown':
      case 'ArrowRight':
        event.preventDefault();
        const nextIndex = (currentIndex + 1) % focusableElements.length;
        focusableElements[nextIndex].focus();
        break;
        
      case 'ArrowUp':
      case 'ArrowLeft':
        event.preventDefault();
        const prevIndex = (currentIndex - 1 + focusableElements.length) % focusableElements.length;
        focusableElements[prevIndex].focus();
        break;
        
      case 'Home':
        event.preventDefault();
        focusableElements[0].focus();
        break;
        
      case 'End':
        event.preventDefault();
        focusableElements[focusableElements.length - 1].focus();
        break;
    }
  }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const app = new MobilityAssistantApp();
  
  // Add keyboard navigation support
  document.addEventListener('keydown', (event) => {
    if (event.ctrlKey || event.altKey || event.metaKey) return;
    app.handleKeyboardNavigation(event);
  });
  
  // Add escape key support for overlays
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      const activeOverlay = document.querySelector('.overlay:not(.hidden)');
      if (activeOverlay) {
        activeOverlay.classList.add('hidden');
        if (activeOverlay.id === 'obstacle-detection-overlay') {
          app.stopObstacleDetection();
        }
      }
    }
  });
  
  // Add resize handler for responsive adjustments
  window.addEventListener('resize', () => {
    // Force a repaint to ensure proper layout
    document.body.style.height = '100vh';
    setTimeout(() => {
      document.body.style.height = '';
    }, 0);
  });
  
  // Add online/offline detection
  window.addEventListener('online', () => {
    app.announceToScreenReader('Connection restored. All features are available.');
  });
  
  window.addEventListener('offline', () => {
    app.announceToScreenReader('Connection lost. Operating in offline mode.');
  });
  
  // Add visibility change detection for better performance
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      // Pause animations and reduce activity when app is hidden
      document.body.classList.add('app-hidden');
    } else {
      document.body.classList.remove('app-hidden');
    }
  });
});

// Service Worker registration for PWA functionality
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then((registration) => {
        console.log('SW registered: ', registration);
      })
      .catch((registrationError) => {
        console.log('SW registration failed: ', registrationError);
      });
  });
}

// Add CSS class for hiding app when not visible
const style = document.createElement('style');
style.textContent = `
  .app-hidden .pulse-animation,
  .app-hidden .loading-spinner {
    animation-play-state: paused;
  }
`;
document.head.appendChild(style);